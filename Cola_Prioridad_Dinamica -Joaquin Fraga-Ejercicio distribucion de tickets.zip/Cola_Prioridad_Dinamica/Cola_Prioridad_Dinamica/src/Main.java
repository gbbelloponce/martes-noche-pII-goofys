import Implementacion.ColaPrioridadDinamica;
import Interface.ColaPrioridadTDA;

public class Main {
    public static void main(String[] args) {
        ColaPrioridadTDA cola = new ColaPrioridadDinamica();

        cola.InicializarColaPrioridad();

        System.out.println("¿Cola vacía?: " + cola.ColaVacia());

        cola.AcolarPrioridad("Se rompio el servidor principal", 999);
        cola.AcolarPrioridad("No me gusta el fondo de pantalla", 0);


        System.out.println("Primero: " + cola.Primero());
        System.out.println("Prioridad del primero: " + cola.Prioridad());

        cola.Desacolar();
        System.out.println("Luego de desacolar:");
        System.out.println("Primero: " + cola.Primero());
        System.out.println("Prioridad del primero: " + cola.Prioridad());



        cola.Desacolar();
        System.out.println("¿Cola vacía?: " + cola.ColaVacia());
    }
}
