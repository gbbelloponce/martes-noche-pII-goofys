import Implementacion.ColaDinamica;
import Interface.ColaTDA;

public class Main {
    public static void main(String[] args) {
        ColaTDA cola = new ColaDinamica();

        cola.InicializarCola();

        System.out.println("¿Impresora vacía?: " + cola.ColaVacia());

        cola.Acolar(1);
        cola.Acolar(2);
        cola.Acolar(3);
        cola.Acolar(4);
        cola.Acolar(5);


        System.out.println("Primer archivo que es impreso: " + cola.Primero()); // 10

        cola.Desacolar();
        System.out.println("segundo: " + cola.Primero()); // 20

        cola.Acolar(40);
        System.out.println("tercero: " + cola.Primero()); // 20

        cola.Desacolar();
        System.out.println("cuarto: " + cola.Primero()); // 30

        cola.Desacolar();
        System.out.println("quinto: " + cola.Primero()); // 40

        cola.Desacolar();
        System.out.println("último en aparecer: " + cola.Primero());

        cola.Desacolar();
        System.out.println("¿Impresora vacía?: " + cola.ColaVacia()); // true
    }
}