import Implementacion.PilaDinamica;
import Interfaces.PilaTDA;

public class Main {

    public static void main(String[] args) {
        PilaTDA historial = new PilaDinamica();
        historial.InicializarPila();

        // 1 = fi.uba.ar | 2 = campus.utn.edu.ar | 3 = stackoverflow.com

        System.out.println("Visitás: " + url(1));
        historial.Apilar(1);

        System.out.println("Visitás: " + url(2));
        historial.Apilar(2);

        System.out.println("Visitás: " + url(3));
        historial.Apilar(3);

        // Usuario presiona "Atrás"
        System.out.println("\n[Atrás] Salís de: " + url(historial.Tope()));
        historial.Desapilar();
        System.out.println("Ahora estás en: " + url(historial.Tope()));

        // Usuario presiona "Atrás" de nuevo
        System.out.println("\n[Atrás] Salís de: " + url(historial.Tope()));
        historial.Desapilar();
        System.out.println("Ahora estás en: " + url(historial.Tope()));
    }

    static String url(int codigo) {
        if (codigo == 1) return "fi.uba.ar";
        if (codigo == 2) return "campus.utn.edu.ar";
        if (codigo == 3) return "stackoverflow.com";
        return "desconocido";
    }
}